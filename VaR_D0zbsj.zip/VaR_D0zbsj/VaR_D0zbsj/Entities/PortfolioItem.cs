﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VaR_D0zbsj.Entities
{
    public class PortfolioItem
    {
        public string Index { get; set; }
        public decimal Volume { get; set; }

    }
}
